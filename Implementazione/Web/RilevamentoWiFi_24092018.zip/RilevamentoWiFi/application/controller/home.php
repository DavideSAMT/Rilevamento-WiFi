<?php

class Home {

    /**
     * Carica la pagina che visualizza i MAC_Address
     */
    public function index() {
        // Controllo se la sessione é stata creata
        // se l'utente non ha una sessione viene rimandato al Login
        if (!isset($_SESSION['user'])) {
            $str = URL;
            header("location: $str");
        }
        // Richiamo la classe per poter ricavare tutti gli Address
        require_once 'application/models/connection.php';
        $connection = new Connection("127.0.0.1", "root", "", "RilevamentoWiFi");
        $address = $connection->getAddress();
        // A dipendenza del utente loggato vengono visualizzate pagine differenti
        if (!strcmp($_SESSION['user'], "guest")) {
            require 'application/views/home/index.php';
        } else if (!strcmp($_SESSION['user'], "admin")) {
            require 'application/views/admin/index.php';
        }
    }

    /**
     * Carica la pagina che visualizza le entrate
     */
    public function entrata() {
        if (!isset($_SESSION['user'])) {
            $str = URL;
            header("location: $str");
        }
        require_once 'application/models/connection.php';
        $connection = new Connection("127.0.0.1", "root", "", "RilevamentoWiFi");
        $entrate = $connection->getEntrate();
        require 'application/views/home/entrata.php';
    }

    /**
     * Carica la pagina che visualizza le uscite
     */
    public function uscita() {
        if (!isset($_SESSION['user'])) {
            $str = URL;
            header("location: $str");
        }
        require_once 'application/models/connection.php';
        $connection = new Connection("127.0.0.1", "root", "", "RilevamentoWiFi");
        $uscite = $connection->getUscite();
        require 'application/views/home/uscita.php';
    }

    /**
     * Carica la pagina che visualizza i dati personali
     */
    public function datiPersonali() {
        if (!isset($_SESSION['user'])) {
            $str = URL;
            header("location: $str");
        }
        require_once 'application/models/connection.php';
        $connection = new Connection("127.0.0.1", "root", "", "RilevamentoWiFi");
        $dati = $connection->getDatiPersonali();
        if (!strcmp($_SESSION['user'], "guest")) {
            require 'application/views/home/datiPersonali.php';
        } else if (!strcmp($_SESSION['user'], "admin")) {
            require 'application/views/admin/datiPersonali.php';
        }
    }

    /**
     * Salva nel database la nuova black list degli address
     */
    function salvaAddress() {
        require_once 'application/models/connection.php';
        $connection = new Connection("127.0.0.1", "root", "", "RilevamentoWiFi");
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $connection->setAddress($_POST);
            $str = URL;
            header("location: $str" . "home/index");
        }
    }

    /**
     * Carica la pagina di modifica per i dati personali
     */
    function modificaDati() {
        require_once 'application/models/connection.php';
        $connection = new Connection("127.0.0.1", "root", "", "RilevamentoWiFi");
    }

}
