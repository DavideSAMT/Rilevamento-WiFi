<?php

class Login
{

    public function index()
    {
      require_once 'application/models/connection.php';
      $connection = new Connection("127.0.0.1","root","","RilevamentoWiFi");
      require 'application/views/login/index.php';
    }

    public function log()
    {
    	require_once 'application/models/connection.php';
    	$connection = new Connection("127.0.0.1","root","","RilevamentoWiFi");
    	if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $user = $_POST["username"];
            $pass = $_POST["pwd"];
        }
        if ((strcmp($user, "") || strcmp($pass, ""))) {
        	$var = ($connection->userControll($user, $pass));
        	switch ($var) {
        		case 1: // LOGIN
                                
        			$_SESSION['user'] = $user;
        			$str = URL."home/index/";
        			header("location: $str");
        			break;
        		
        		case 2: // PASSWORD SBAGLIATA
        			$this->index();
        			break;

        		default: // UTENTE NON REGISTRATO
        			$this->index();
        			break;
        	}
        } 
    }
}