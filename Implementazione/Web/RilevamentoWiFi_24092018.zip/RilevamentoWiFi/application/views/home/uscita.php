<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">

        <title>Uscita</title>

        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <!-- Popper JS -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    </head>
    <body style="background-color: #000">
        <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
            <a class="navbar-brand" href="#">
                <img src="application/img/logo.png" alt="CPT" style="width:50px;">
            </a>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo URL ?>/home/index">Address</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo URL ?>/home/entrata">Entrata</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="#">Uscita</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo URL ?>/home/datiPersonali">Dati Personali</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo URL ?>/logout/index">Log out</a>
                </li>
            </ul>
        </nav>
        <div class="container-fluid">
            <input class="form-control" id="search" type="text" placeholder="Search..">
            <table class="table table-dark table-striped">
                <thead>
                    <tr>
                        <th>MAC Address</th>
                        <th>Orario</th>
                    </tr>
                </thead>
                <tbody id="tb">
                    <?php for ($i = 0; $i < count($uscite); $i++): ?>
                        <tr>
                            <?php for ($j = 0; $j < count($uscite[$i]); $j++): ?>
                                <td>
                                    <?php echo $uscite[$i][$j] ?>		
                                </td>

                            <?php endfor ?>
                        </tr>
                    <?php endfor ?>
                </tbody>
            </table>
        </div>
        <script type="text/javascript">
            $(document).ready(function () {
                $("#search").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#tb tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });
            });
        </script>
    </body>
</html>