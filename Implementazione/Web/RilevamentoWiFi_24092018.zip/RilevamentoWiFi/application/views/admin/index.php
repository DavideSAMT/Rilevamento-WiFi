<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">

        <title>Home</title>

        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <!-- Popper JS -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
        <style>
            #bs {
                position: absolute;
                right: 1%;
                bottom: 1%;
                z-index: 3;
            }
        </style>
    </head>
    <body style="background-color: #000">
        <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
            <a class="navbar-brand" href="#">
                <img src="application/img/logo.png" alt="CPT" style="width:50px;">
            </a>
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Address</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo URL ?>/home/entrata">Entrata</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo URL ?>/home/uscita">Uscita</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo URL ?>/home/datiPersonali">Dati Personali</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo URL ?>/logout/index">Log out</a>
                </li>
            </ul>
        </nav>
        <div class="container-fluid">
            <input class="form-control" id="search" type="text" placeholder="Search..">
            <div class="alert alert-warning alert-dismissible fade show" id="warning" hidden>
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong>Warning!</strong> Ricordati di salvare i dati modificati con l'apposito pulsante!
            </div>
            <form action="<?php echo URL?>home/salvaAddress" method="POST">
                <table class="table table-dark table-striped">
                    <thead>
                        <tr>
                            <th>MAC Address</th>
                            <th>Is in Black List</th>
                        </tr>
                    </thead>
                    <tbody id="tb">
                        <?php for ($i = 0; $i < count($address); $i++): ?>
                            <tr>
                                <?php for ($j = 0; $j < count($address[$i]); $j++): ?>
                                    <td>
                                        <?php
                                        if ($address[$i][$j] == "1" || $address[$i][$j] == "0") {
                                            echo "<input type='number' min='0' max='1' value='" . $address[$i][$j] . "' onChange='verButton()' name='$mac'>";
                                        } else {
                                            echo $address[$i][$j];
                                            $mac = $address[$i][$j];
                                        }
                                        ?>			
                                    </td>

                                <?php endfor ?>
                            </tr>
                        <?php endfor ?>
                    </tbody>
                </table>
                <button type="submit" class="btn btn-primary" id="bs" disabled>Salva dati</button>
            </form>
        </div>

        <script type="text/javascript">
            $(document).ready(function () {
                $("#search").on("keyup", function () {
                    var value = $(this).val().toLowerCase();
                    $("#tb tr").filter(function () {
                        $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    });
                });
            });
            /**
             * Funzione che abilita il pulsante "Salva dati" e manda un Warning all'utente  quando viene cambiato un valore
             */
            function verButton() {
                var button = document.getElementById("bs");
                button.disabled = false;
                var warning = document.getElementById("warning");
                warning.hidden = false;
            }
        </script>
    </body>
</html>