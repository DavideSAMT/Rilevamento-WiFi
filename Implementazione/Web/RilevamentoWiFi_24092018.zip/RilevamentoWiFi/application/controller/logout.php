<?php

/**
 * 
 */
class Logout {

    public function index() {
        session_destroy();
        $str = URL . "login/index/";
        header("location: $str");
    }

}
