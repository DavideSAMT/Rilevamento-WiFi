<?php

/**
 * Classe che permette di collegarsi al database RilevamentoWiFi e di gestire i suoi dati.
 */
class Connection {

    /**
     * Hostname del Database
     */
    private $hostname;

    /**
     * Username con la quale ci si può connettere al Database
     */
    private $username;

    /**
     * Password dello username
     */
    private $password;

    /**
     * Nome del Database alla quale ci si vuole connettere
     */
    private $dbname;

    /**
     * Contiene la connessione al database
     */

    /**
     * 
     * @param type $hostname
     * @param type $username
     * @param type $password
     * @param type $dbname
     */
    function __construct($hostname, $username, $password, $dbname) {
        $this->hostname = $hostname;
        $this->username = $username;
        $this->password = $password;
        $this->dbname = $dbname;

        $conn = mysqli_connect($this->hostname, $this->username, $this->password, $this->dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
    }

    /**
     * 
     * @param type $msg
     */
    function phpAlert($msg) {
        echo '<script type="text/javascript">alert("' . $msg . '")</script>';
    }

    /**
     * 
     * @param type $user
     * @param type $password
     * @return int
     */
    public function userControll($user, $password) {
        $conn = mysqli_connect($this->hostname, $this->username, $this->password, $this->dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        $sql = "SELECT password FROM users WHERE username = '$user'";
        $result = mysqli_query($conn, $sql);
        $row = mysqli_num_rows($result);
        if ($row > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                if (!(strcmp($password, $row["password"]))) {
                    // LOGIN
                    $this->phpAlert("Login avvenuto con successo");
                    return 1;
                } else {
                    // PASSWORD SBAGLIATA
                    $this->phpAlert("Login non avvenuto, password errata");
                    return 2;
                }
            }
        } else {
            // UTENTE NON REGISTRATO
            $this->phpAlert("Utente inesistente");
            return 3;
        }
    }

    /**
     * 
     * @return array
     */
    public function getAddress() {
        $conn = mysqli_connect($this->hostname, $this->username, $this->password, $this->dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $sql = "SELECT * FROM address";

        $result = mysqli_query($conn, $sql);
        $row = mysqli_num_rows($result);
        $row = array();
        while ($s = mysqli_fetch_array($result, MYSQLI_NUM)) {
            array_push($row, $s);
        }
        return $row;
    }

    /**
     * 
     * @return array
     */
    function getEntrate() {
        $conn = mysqli_connect($this->hostname, $this->username, $this->password, $this->dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $sql = "SELECT * FROM entrata";

        $result = mysqli_query($conn, $sql);
        $row = mysqli_num_rows($result);
        $row = array();
        while ($s = mysqli_fetch_array($result, MYSQLI_NUM)) {
            array_push($row, $s);
        }
        return $row;
    }

    /**
     * 
     * @return array
     */
    function getUscite() {
        $conn = mysqli_connect($this->hostname, $this->username, $this->password, $this->dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $sql = "SELECT * FROM uscita";

        $result = mysqli_query($conn, $sql);
        $row = mysqli_num_rows($result);
        $row = array();
        while ($s = mysqli_fetch_array($result, MYSQLI_NUM)) {
            array_push($row, $s);
        }
        return $row;
    }

    /**
     * 
     * @return array
     */
    function getDatiPersonali() {
        $conn = mysqli_connect($this->hostname, $this->username, $this->password, $this->dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $sql = "SELECT * FROM datiPersonali";

        $result = mysqli_query($conn, $sql);
        $row = mysqli_num_rows($result);
        $row = array();
        while ($s = mysqli_fetch_array($result, MYSQLI_NUM)) {
            array_push($row, $s);
        }
        return $row;
    }

    /**
     * 
     * @param type $array
     */
    function setAddress($array) {
        $conn = mysqli_connect($this->hostname, $this->username, $this->password, $this->dbname);
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        foreach ($array as $name => $value) {
            $sql = "UPDATE address SET BlackList = $value WHERE MAC_Address = '$name'";
            $result = mysqli_query($conn, $sql);
        }
    }

}
