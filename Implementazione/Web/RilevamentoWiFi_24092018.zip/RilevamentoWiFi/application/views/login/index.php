<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>LOGIN RILEVAMENTO WIFI</title>

		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

		<!-- Popper JS -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

		<style type="text/css">

			.jumbotron {
			  position: absolute;
			  top: 50%;
			  left: 15%;
			  transform: translateY(-50%);
			}
		</style>

	</head>
	<body class="jumbotron">
		<div class="container" style="width:1025px;">
			<h1>LOGIN RILEVAMENTO TRAMITE WI-FI</h1>
			<form action="<?php echo URL?>login/log" method="POST">
				<div class="form-group">
					<label for="username">Username:</label>
                                        <input type="text" class="form-control" name="username" id="username" required>
				</div>
				<div class="form-group">
		    		<label for="pwd">Password:</label>
                                <input type="password" class="form-control" id="pwd" name="pwd" required>
		  		</div>
		  		<div class="form-group">
					<button type="submit" class="btn btn-primary btn-block">Login</button>
				</div>	
			</form>
		</div>
	</body>
</html>